import 'package:capsa/functions/hexcolor.dart';
import 'package:flutter/material.dart';import 'package:capsa/functions/custom_print.dart';

BoxDecoration bgDecoration = BoxDecoration(
// color: Color(0xFFB8B8B8).withOpacity(0.1),
//   color: HexColor("#F5FBFF").withOpacity(0.8),
// color: const Color(0xffc6c6c6),
//   image: DecorationImage(
//     image: AssetImage("assets/images/bgpage.png"),
// // fit: BoxFit.contain,
//
//     colorFilter: new ColorFilter.mode(HexColor("#F5FBFF").withOpacity(0.8), BlendMode.dstATop),
//     repeat: ImageRepeat.repeat,
//   ),
);
