class TransactionTrackerModel {
  String transactionMonth;
  String deposit;
  String withdrawal;

  TransactionTrackerModel(
      {this.transactionMonth, this.deposit, this.withdrawal});
}
