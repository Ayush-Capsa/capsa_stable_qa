//
// Generated file. Do not edit.
//

// ignore_for_file: lines_longer_than_80_chars


import 'package:fluttertoast/fluttertoast_web.dart';

import 'package:syncfusion_flutter_pdfviewer_web/pdfviewer_web.dart';


import 'package:flutter_web_plugins/flutter_web_plugins.dart';

// ignore: public_member_api_docs
void registerPlugins(Registrar registrar) {

  FluttertoastWebPlugin.registerWith(registrar);

  SyncfusionFlutterPdfViewerPlugin.registerWith(registrar);

  registrar.registerMessageHandler();
}
