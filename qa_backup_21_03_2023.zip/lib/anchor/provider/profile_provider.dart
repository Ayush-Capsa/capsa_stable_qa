import 'package:capsa/anchor/Mobile_Profile/New_Admin.dart';
import 'package:capsa/common/constants.dart';
import 'package:capsa/functions/call_api.dart';

import 'package:capsa/providers/auth_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;

import 'package:intl/intl.dart';

import 'package:universal_html/html.dart' as html;

class ProfileProvider extends ChangeNotifier{



}